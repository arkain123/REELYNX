﻿#include <iostream>
#include <fstream>

using namespace std;

struct NOTES {
	string last_name;
	string number;
	int date[3];
	int salary;

	void vvod() {

		cout << "Введите фамилию: "; cin >> last_name;
		cout << "Введите номер телефона: "; cin >> number;
		cout << "Введите оклад: "; cin >> salary;
		cout << "Введите дату рождения: ";
		for (int i = 0; i < 3; ++i) cin >> date[i];
		cout << endl;
	}

	void vivod() {
		cout << "Фамилия: " << last_name << endl;
		cout << "Номер телефона: " << number << endl;
		cout << "Оклад: " << salary << endl;
		cout << "Дата рождения: ";
		for (int i = 0; i < 3; ++i) cout << date[i] << " ";
		cout << endl << endl;
	}
};

int main() {
	setlocale(LC_ALL, "rus");
	int n = 1;
	FILE* file1;
	file1 = fopen("E:/BNTU/REELYNX/Borodkin/Lab9/Lab9_2/1.dat", "rb");
	if (file1 == NULL) {
		cout << "File not found!" << endl;
	}
	else {
		fseek(file1, 0L, SEEK_END);
		int size = ftell(file1) / sizeof(NOTES);
		fseek(file1, 0L, SEEK_SET);

		NOTES** note = new NOTES * [size];   //если тут вместо 50 написать size - будет ошибка
		int num = size;
		while (feof(file1))
		{
			note[num] = new NOTES;
			fread(note[num], sizeof(NOTES), 1, file1);
			num++;
			cout << "first file writed\n";
		}
	}
}